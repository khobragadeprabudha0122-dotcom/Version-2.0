# LIFE OS – Android App

Native Android app for LIFE OS. The full app (all 5 sections, themes, greeting, voice) runs inside it, with Android's own
speech recognition and text-to-speech connected, so voice commands and the spoken greeting work properly.

## What the Android version adds
- Speaks the greeting automatically when the app opens (no tap needed)
- Voice commands and hands-free mode use Android's speech engine (English, Hinglish, Hindi)
- The start beep is muted in hands-free mode
- Asks for microphone permission the first time you use voice
- Back button: closes panels first, then goes to Overview, then exits
- Export backup saves a real .json file, Import picks a file from the phone
- Status bar and navigation bar follow the app theme
- All data stays on the phone

---

## Option 1: Get the APK without a computer (GitHub, free)
1. Create a free account on github.com (works on a phone browser).
2. Create a **new private repository**, e.g. `lifeos-app`.
3. Upload all files from this folder (keep the folder structure, including `.github`).
   Easiest: on a computer, drag the unzipped folder into "Add file → Upload files".
4. Open the **Actions** tab. The "Build LIFE OS" workflow starts on its own (about 5–8 minutes).
5. Open the finished run, scroll down to **Artifacts**, and download **LIFE-OS-test-apk**.
6. Unzip it, open `app-debug.apk` on your phone, and allow "Install unknown apps".

## Option 2: Android Studio (on a computer)
1. Install Android Studio (free).
2. File → Open → choose this folder. Wait for "Gradle sync" to finish.
3. Build → Build App Bundle(s) / APK(s) → Build APK(s).
4. The APK will be in `app/build/outputs/apk/debug/`.

---

## Publishing on Google Play Store
1. **Change the app ID** in `app/build.gradle.kts`:
   `applicationId = "com.lifeos.personal"` → something unique like `com.yourname.lifeos`.
   It can never be changed after publishing.
2. **Create a signing key (once).**
   - On GitHub: Actions → "Create signing key" → Run workflow → enter a password and your name.
     Download the `signing-key-KEEP-SAFE` artifact. Keep `lifeos-release.jks` and the password safe forever.
     If you lose them, you can't update the app.
   - Or in Android Studio: Build → Generate Signed Bundle → Create new.
3. **Add 4 secrets** in GitHub: Settings → Secrets and variables → Actions → New secret
   - `KEYSTORE_BASE64` = the full text inside `KEYSTORE_BASE64.txt`
   - `KEYSTORE_PASSWORD` = your password
   - `KEY_ALIAS` = `lifeos`
   - `KEY_PASSWORD` = the same password
4. Run "Build LIFE OS" again. Download **LIFE-OS-play-store** and use the `.aab` file.
5. **Play Console** (play.google.com/console): one-time fee of US$25.
   - Create app → upload the `.aab` under Testing or Production.
   - **Privacy policy:** host `privacy-policy.html` (for example with GitHub Pages) and paste its link. Put your email in it first.
   - **Data safety:** "No data collected / No data shared". Data is stored on the device only.
   - **Microphone:** explain that it's for voice commands.
   - Add screenshots, an icon (512×512) and a feature graphic (1024×500).
   - New personal developer accounts must run a **closed test with at least 12 testers for 14 days**
     before they can publish to Production.
6. **For every update:** increase `versionCode` (1 → 2 → 3…) and `versionName` in `app/build.gradle.kts`.

## Updating the app content
The whole app is one file: `app/src/main/assets/index.html`. Replace it with a new version and rebuild.
Keep the `<script>` Android bridge block at the top of the file. It connects voice and files to Android.

## Voice notes
- Speech recognition uses the phone's Google speech service. It usually needs internet.
- For Hindi voice: Settings (in the app) → Voice commands → Voice language → हिन्दी.
  The phone must also have Hindi text-to-speech (Android Settings → Text-to-speech).
