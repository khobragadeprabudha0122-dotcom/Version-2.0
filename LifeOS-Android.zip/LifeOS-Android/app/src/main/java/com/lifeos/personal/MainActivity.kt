package com.lifeos.personal

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private val handler = Handler(Looper.getMainLooper())

    // ---- speech recognition ----
    private var recognizer: SpeechRecognizer? = null
    private var currentSid = 0
    private var pendingListen: (() -> Unit)? = null
    private var pendingSid = 0
    private var beepMuted = false

    // ---- text to speech ----
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private data class SpeakJob(val text: String, val lang: String, val rate: Double, val id: String)
    private val speakQueue = mutableListOf<SpeakJob>()

    // ---- files ----
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSaveText: String? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val job = pendingListen
            pendingListen = null
            if (granted) {
                job?.invoke()
            } else {
                js("__lifeos.onError($pendingSid,'not-allowed')")
                js("__lifeos.onEnd($pendingSid)")
            }
        }

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
            fileCallback = null
        }

    private val createDoc =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            val text = pendingSaveText
            pendingSaveText = null
            if (uri != null && text != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                    js("toast('Backup saved.')")
                } catch (e: Exception) {
                    js("toast('Could not save the file','err')")
                }
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0E0B17"))
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Keep the page clear of the status bar, navigation bar and keyboard
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            textZoom = 100
        }
        web.setBackgroundColor(Color.parseColor("#0E0B17"))

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, url)); true
                } catch (e: Exception) { true }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    pickFile.launch("*/*"); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        web.addJavascriptInterface(VoiceBridge(), "AndroidVoice")
        web.addJavascriptInterface(FilesBridge(), "AndroidFiles")
        web.addJavascriptInterface(UiBridge(), "AndroidUI")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(ttsListener)
                val jobs = speakQueue.toList()
                speakQueue.clear()
                jobs.forEach { doSpeak(it) }
            }
        }

        if (savedInstanceState == null) {
            web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }

        // Back button: close panels / go to Overview first, then exit
        onBackPressedDispatcher.addCallback(this) {
            web.evaluateJavascript("(window.__lifeosBack&&window.__lifeosBack())?'1':'0'") { r ->
                if (r == null || !r.contains("1")) finish()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        recognizer?.cancel()
        tts?.stop()
        unmuteBeep()
        js("window.__lifeos&&__lifeos.onPause()")
    }

    override fun onResume() {
        super.onResume()
        js("window.__lifeos&&__lifeos.onResume()")
    }

    override fun onDestroy() {
        unmuteBeep()
        recognizer?.destroy()
        tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ helpers
    private fun js(code: String) {
        runOnUiThread {
            if (::web.isInitialized) web.evaluateJavascript("try{$code}catch(e){}", null)
        }
    }

    private val audio by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    /** Hands-free restarts listening often; mute the start beep so it isn't annoying. */
    private fun muteBeep() {
        try {
            if (!audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                beepMuted = true
            }
        } catch (_: Exception) { }
    }

    private fun unmuteBeep() {
        if (!beepMuted) return
        beepMuted = false
        try { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ speech recognition
    private fun beginListen(lang: String, interim: Boolean, continuous: Boolean, sid: Int) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingSid = sid
            pendingListen = { beginListen(lang, interim, continuous, sid) }
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("__lifeos.onError($sid,'service-not-allowed')")
            js("__lifeos.onEnd($sid)")
            return
        }
        if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val rec = recognizer ?: return
        rec.cancel()
        currentSid = sid

        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                js("__lifeos.onStart($sid)")
                if (continuous) handler.postDelayed({ unmuteBeep() }, 400)
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                unmuteBeep()
                if (sid != currentSid) return
                val code = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> "network"
                    SpeechRecognizer.ERROR_AUDIO -> "audio-capture"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "busy"
                    SpeechRecognizer.ERROR_CLIENT -> "aborted"
                    else -> "unknown"
                }
                js("__lifeos.onError($sid,'$code')")
                js("__lifeos.onEnd($sid)")
            }

            override fun onResults(results: Bundle?) {
                unmuteBeep()
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (text.isNotEmpty()) js("__lifeos.onResult($sid,${JSONObject.quote(text)},true)")
                js("__lifeos.onEnd($sid)")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (text.isNotEmpty()) js("__lifeos.onResult($sid,${JSONObject.quote(text)},false)")
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, interim)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        if (continuous) muteBeep()
        try {
            rec.startListening(intent)
        } catch (e: Exception) {
            unmuteBeep()
            js("__lifeos.onError($sid,'unknown')")
            js("__lifeos.onEnd($sid)")
        }
    }

    // ------------------------------------------------------------------ text to speech
    private val ttsListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) { js("__lifeos.onSpeakStart('$utteranceId')") }
        override fun onDone(utteranceId: String?) { js("__lifeos.onSpeakEnd('$utteranceId')") }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { js("__lifeos.onSpeakEnd('$utteranceId')") }
        override fun onError(utteranceId: String?, errorCode: Int) { js("__lifeos.onSpeakEnd('$utteranceId')") }
        override fun onStop(utteranceId: String?, interrupted: Boolean) { js("__lifeos.onSpeakEnd('$utteranceId')") }
    }

    private fun doSpeak(job: SpeakJob) {
        val engine = tts
        if (!ttsReady || engine == null) { speakQueue.add(job); return }
        val wanted = Locale.forLanguageTag(job.lang)
        val ok = try { engine.isLanguageAvailable(wanted) } catch (e: Exception) { -2 }
        engine.language = if (ok >= TextToSpeech.LANG_AVAILABLE) wanted else Locale("en", "IN")
        engine.setSpeechRate(job.rate.toFloat())
        engine.speak(job.text, TextToSpeech.QUEUE_FLUSH, null, job.id)
    }

    // ------------------------------------------------------------------ JS bridges
    inner class VoiceBridge {
        @JavascriptInterface
        fun startListening(lang: String, interim: Boolean, continuous: Boolean, sid: Int) {
            runOnUiThread { beginListen(lang, interim, continuous, sid) }
        }
        @JavascriptInterface
        fun stopListening() { runOnUiThread { recognizer?.stopListening() } }
        @JavascriptInterface
        fun abortListening() { runOnUiThread { currentSid = -1; recognizer?.cancel(); unmuteBeep() } }
        @JavascriptInterface
        fun speak(text: String, lang: String, rate: Double, id: String) {
            runOnUiThread { doSpeak(SpeakJob(text, lang, rate, id)) }
        }
        @JavascriptInterface
        fun stopSpeaking() { runOnUiThread { speakQueue.clear(); tts?.stop() } }
    }

    inner class FilesBridge {
        @JavascriptInterface
        fun saveText(name: String, text: String) {
            runOnUiThread {
                pendingSaveText = text
                try { createDoc.launch(name) } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Could not open the save screen", Toast.LENGTH_SHORT).show()
                }
            }
        }
        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("LIFE OS backup", text))
            }
        }
    }

    inner class UiBridge {
        @JavascriptInterface
        fun setBars(hex: String, light: Boolean) {
            runOnUiThread {
                try {
                    val c = Color.parseColor(hex)
                    root.setBackgroundColor(c)
                    web.setBackgroundColor(c)
                    val ctl = WindowInsetsControllerCompat(window, root)
                    ctl.isAppearanceLightStatusBars = light
                    ctl.isAppearanceLightNavigationBars = light
                } catch (_: Exception) { }
            }
        }
    }
}
